<?php
   session_start();
?>
<body>
<!--<h1>Register, login and logout user php mysql</h1>-->
<!--<h1>Home</h1>-->
<h4>註冊成功!歡迎使用, <?php echo $_SESSION['account_number']; ?> !</h4>
</body>