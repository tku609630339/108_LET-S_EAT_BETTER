 <HTML>
<HEAD>
    <meta charset="UTF-8">


</HEAD>
<body bgcolor="#F0FFF0" text="#000000" link="#0066cc" vlink="#336600"> 
 

    <div style="text-align:center;"><b><h1>LET'S EAT BETTER</h1></b></div>
<div style="text-align:center;"><b><h1>管理端介面</h1></b></div>

<table width="100" height="50">
    <tr align="center">
    <center><a href='logout.php'>logout</a></center>
</tr>
</table>
<table width="100" height="50">

　
<center><img src="食物.jpg"  height="100" width="100">
<img src="會員資料.jpg"  height="100" width="100"></center>

  <center><input type="button" align="center" value="食物資料管理" style="width:100px;height:40px;font-size:14px;border:2px lime outset;background-color:lime;" onclick="location.href='../管理端/manage.php'">
  <input type="button" value="會員資料管理" style="width:100px;height:40px;font-size:14px;border:2px pink outset;background-color:pink;" onclick="location.href='../管理端/usersmanage.php'"></center>
</table>


<table width="100" height="50">
　
<center><img src="討論區.jpg" " height="100" width="100">
<img src="紀錄.jpg" " height="100" width="100"></center>

  <center><input type="button" align='center'; value="討論區管理" style="width:100px;height:40px;font-size:14px;border:2px red outset;background-color:red;" onclick="location.href='../管理端/dis-manage.php'">
  <input type="button" value="個人紀錄管理" style="width:100px;height:40px;font-size:14px;border:2px yellow outset;background-color:yellow;" onclick="location.href='../管理端/re-manage.php'"></center>



</BODY>
</HTML>